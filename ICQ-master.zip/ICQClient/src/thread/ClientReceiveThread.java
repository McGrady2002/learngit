package thread;

import javax.swing.*;

import entity.Node;
import entity.UserLinkList;
import frame.MainFrame;
import frame.UserConf;

import java.io.*;
import java.net.*;

/*
 * 聊天客户端消息收发类
 */
public class ClientReceiveThread extends Thread {
	private JComboBox combobox;
	private JTextArea textarea;

	Socket socket;
	ObjectOutputStream output;
	ObjectInputStream input;
	JTextField showStatus;

	public ClientReceiveThread(Socket socket, ObjectOutputStream output, ObjectInputStream input, JComboBox combobox,
			JTextArea textarea, JTextField showStatus) {

		this.socket = socket;
		this.output = output;
		this.input = input;
		this.combobox = combobox;
		this.textarea = textarea;
		this.showStatus = showStatus;
	}

	public void run() {
		while (!socket.isClosed()) {
			try {
				String type = (String) input.readObject();

				if (type.equalsIgnoreCase("系统信息")) {
					String sysmsg = (String) input.readObject();
					textarea.append("系统信息: " + sysmsg);
				} else if (type.equalsIgnoreCase("服务关闭")) {
					output.close();
					input.close();
					socket.close();

					textarea.append("服务器已关闭！\n");

					break;
				} else if (type.equalsIgnoreCase("聊天信息")) {
					String message = (String) input.readObject();
					textarea.append(message);
				} else if (type.equalsIgnoreCase("用户列表")) {
					MainFrame.userlinklist = new UserLinkList();
					String userlist = (String) input.readObject();
					String usernames[] = userlist.split("\n");
					String userport = (String) input.readObject();
					String userports[] = userport.split("\n");
					int ports[] = new int[userports.length];
					for (int i = 0; i < userports.length; i++) {
						ports[i] = Integer.parseInt(userports[i]);
						MainFrame.userlinklist.addUser(new Node(usernames[i], ports[i]));
					}
					combobox.removeAllItems();
					System.out.println(usernames.length + "  " + userports.length);
					int i = 0;
					combobox.addItem("所有人");
					while (i < usernames.length) {
						if (!usernames[i].equals(UserConf.userInputName)) {
							combobox.addItem(usernames[i]);
						}
						System.out.println(usernames[i] + ":" + ports[i]);
						i++;
					}
					combobox.setSelectedIndex(0);
					showStatus.setText("在线用户 " + usernames.length + " 人");
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
}
