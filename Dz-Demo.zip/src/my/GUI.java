package my;

import java.awt.FlowLayout;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class GUI {
	static JMenuBar menubar = new JMenuBar();

	public static void main(String[] args) {
		ArrayList<Ball> b = new ArrayList<>();
		for (int i = 0; i < 3; i++) {
			b.add(new Ball());
		}
		MyPanel p = new MyPanel(b);
		JFrame frame = new JFrame();
//	    Graphics g;
//	    g=p.getGraphics();
//	    MyListener ml=new MyListener(g);
//	    p.addMouseListener(ml);
//	    p.addMouseMotionListener(ml);
		frame.setJMenuBar(menubar);
		JMenu menu = new JMenu("菜单");
		menubar.add(menu);
		JMenu menu2 = new JMenu("难度");
		menubar.add(menu2);
		JMenuItem easy = new JMenuItem("简单");
		menu2.add(easy);
//	    System.out.println(menubar.);
		/* panel thread, paint the monkey */
		frame.setSize(700, 700);
		JLabel jl = new JLabel("aaa");
//		frame.setLayout(new FlowLayout());
//		frame.add(jl);
		frame.add(p);
//	    System.out.println(frame.getHeight());
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		p.My_start(); // 框架调用pack()之前 无法获得Jpanel的正确尺寸

	}
}