package my;

import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class GUI{
    static JMenuBar menubar=new JMenuBar();

	public static void main(String[] args) {
		Ball b=new Ball();
	    MyPanel p = new MyPanel(b);
	    b.setPanel(p);
	    JFrame frame = new JFrame();
//	    Graphics g;
//	    g=p.getGraphics();
//	    MyListener ml=new MyListener(g);
//	    p.addMouseListener(ml);
//	    p.addMouseMotionListener(ml);
	    frame.setJMenuBar(menubar);
	    JMenu menu=new JMenu("菜单");
	    menubar.add(menu);
	    JMenu menu2=new JMenu("难度");
	    menubar.add(menu2);
	    JMenuItem easy=new JMenuItem("简单");
	    menu2.add(easy);
//	    System.out.println(menubar.);
	    /* panel thread, paint the monkey */
	    frame.add(p);
	    frame.setSize(700, 700);
//	    System.out.println(frame.getHeight());
	    frame.setLocationRelativeTo(null);
	    frame.setVisible(true);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}