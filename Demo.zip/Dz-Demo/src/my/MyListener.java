package my;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
 
import javax.swing.JFrame;
 
/**
 * 鼠标监听器的类
 * 
 * @author Administrator
 * 
 */
public class MyListener extends MouseAdapter {
	Graphics g;
	private int x = 100, y = 100;
	private int width = 10, height = 10;
 
	public MyListener(Graphics g) {
		this.g = g;
	}
 
	public void mouseMoved(MouseEvent e) {
			g.setColor(java.awt.Color.black);
			g.fillRect(x, y, width, height);
			x = e.getX();
			y=e.getY();
			g.setColor(java.awt.Color.green);
			g.fillRect(x, y, width, height);
	}
 
	/**
	 * 得到x的方法
	 * 
	 * @return：x
	 */
 
}
 