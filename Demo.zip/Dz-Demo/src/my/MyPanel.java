package my;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * MyPanel.java.
 * 
 * @author Kaiyan Zhang
 */
public class MyPanel extends JPanel {
	int x = 400, y = 100;
	int n = 1, m = 1;
	Ball b;

//	MyListener ml=null;
	public MyPanel(Ball b) {
//	    b = new Ball();
		this.b = b;
//		b.setPanel(this);
		Graphics g;
		g = this.getGraphics();
		MyListener ml = new MyListener(g);
		this.addMouseListener(ml);
		this.addMouseMotionListener(ml);

		Random ran = new Random();
		b.x = ran.nextInt(500);
		b.y = ran.nextInt(500);
		b.m = ran.nextInt(10) + 1;
		b.n = ran.nextInt(10) + 1;
		b.start();
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.setColor(Color.black);
		g.fillOval(b.x, b.y, 20, 20);

	}
}

class Ball extends Thread {
	int x = 400;
	int y = 100;
	int n = 10, m = 5;
	MyPanel p;

	public void setPanel(MyPanel p) {
		this.p = p;
	}

	@Override
	public void run() {
		while (true) {
			y += m;
			x += n;
			if (y > p.getHeight() - 20 || y < 0) {
				m = -m;
			} else {
			}
			if (x < 0 || x > p.getWidth() - 20) {
				n = -n;
			}
			p.repaint();
			try {
				sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
