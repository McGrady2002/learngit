package frame;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import thread.ChatReceiveThread;
import thread.ClientReceiveThread;
import thread.TalkReceive;
import thread.TalkSend;

public class ChatFrame extends JFrame {
	public JTextArea messageShow;// 客户端的信息显示
	JScrollPane messageScrollPane;// 信息显示的滚动条
	public JTextField clientMessage;// 客户端消息的发送
	public JButton clientMessageButton;// 发送消息
	public ChatReceiveThread recethread;
	public DatagramSocket socket;
	int toport;
	String toname;
	public TalkSend send;
	public TalkReceive recev;
	public ChatReceiveThread chatrec;
	public int quit = 0;

	public int isconnect = 0;

	private DatagramSocket client;// 发送端
	BufferedReader br; // 输入流
	private String toIp = "localhost";// 发送目标ip
	public int toPort;// 发送目标端口 和接收端使用端口一致

	public ChatFrame(String str) {
		super(str);
		toname = str;

		Container con = this.getContentPane();
		JPanel jp = new JPanel();
		clientMessage = new JTextField(25);
//		con.setLayout(getLayout());
		messageShow = new JTextArea();
		messageShow.setEditable(false);
//		con.add(messageShow);
		messageScrollPane = new JScrollPane(messageShow, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		messageScrollPane.setPreferredSize(new Dimension(400, 300));
		messageScrollPane.revalidate();
//		con.add(messageScrollPane);
		clientMessageButton = new JButton("发送");
//		con.add(clientMessageButton);/
		jp.add(messageScrollPane);
		jp.add(clientMessage);
		jp.add(clientMessageButton);
		clientMessageButton.addActionListener(null);
		this.add(jp);
		this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		this.setVisible(false);
		this.setBounds(500, 250, 400, 400);
		this.clientMessage.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				sendmess(clientMessage.getText());
				clientMessage.setText(" ");
			}
		});
		this.clientMessageButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				sendmess(clientMessage.getText());
				clientMessage.setText(" ");
			}
		});
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
//						quit=1;
				isconnect = 0;
//				client.close();
//						System.exit(0);
			}
		});
//		chatrec = new ChatReceiveThread(this);
//		chatrec.start();
		setVisible(false);

		try {
			int n = this.toPort + 19070;
			client = new DatagramSocket(null);
//			br = new BufferedReader(new InputStreamReader(System.in));
		} catch (SocketException e) {
			System.out.println("data 错误");
			e.printStackTrace();
		}
	}

	public void sendmess(String data) {
//		this.messageShow.setText("  我:"+data+"\n");
//		while (true) {
			try {
				// 2、准备数据 一定转成字节数组
//			String data1 = br.readLine();
//			String data=frame.clientMessage.getText();
				String data1=UserConf.userInputName+"\n"+data;
				byte[] datas = data1.getBytes();
//				System.out.println("send:" + this.toPort + 107 + " " + this.toIp + " " + this.toPort);
				// 3、封装成DatagramPacket 包裹，需要指定地址
				DatagramPacket packet = new DatagramPacket(datas, 0, datas.length,
						new InetSocketAddress(this.toIp, this.toPort));
				// 4、发送包裹
				client.send(packet);
//			messageShow.setText(data);
//				System.out.println("data1"+"\n");
				messageShow.append("    我:"+data+"\n");
//				System.out.println("working...");
//			if(data.equals("bye")) {
//				break;
//			}
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("错误");
			}
//		client.close();
//		}
	}

}
