package thread;

import javax.swing.JComboBox;

import frame.MainFrame;

public class Mythread extends Thread {

	JComboBox combobox;

	public Mythread(JComboBox combobox) {
		this.combobox = combobox;
	}

	@Override
	public void run() {
		while (true) {
			if (combobox.getSelectedItem() != null) {
//				System.out.println("Judging...");
				if (combobox.getSelectedItem().equals("所有人")) {
					MainFrame.chat.setEnabled(false);
//					System.out.println("no...");
				} else {
					MainFrame.chat.setEnabled(true);
//					System.out.println("ok...");
				}
			}
			try {
				this.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
