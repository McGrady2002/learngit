package thread;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

import javax.swing.JComponent;
import javax.swing.JOptionPane;

import entity.Node;
import frame.ChatFrame;
import frame.MainFrame;

public class TalkReceive extends Thread {
	public DatagramSocket server; // 接收端
	private int port; // 接收端使用端口
	private String from; // 发送方标记
	ChatFrame frame;
	Node node;
	public int quit = 0;

	public TalkReceive(int port) {
//		this.from = from;
//		this.frame=frame;
//		this.node=node;
		try {
			server = new DatagramSocket(port);
			System.out.println("占用:" + port + " " + from + "\n");
		} catch (SocketException e) {
			e.printStackTrace();
			System.out.println("wrong：" + port + " " + from);
			JOptionPane.showMessageDialog(null, "端口号已被占用，请重新输入端口号", "错误", JOptionPane.ERROR_MESSAGE);
			;
			MainFrame.clientListener.DisConnect();
			MainFrame.clientListener.mainFrame.showStatus.setText("");

		}
	}

	@Override
	public void run() {
		while (true) {
			try {
				if (quit == 1) {
					System.out.println("out");
					break;
				}
				System.out.println("receiving...");
				// 2、准备容器封装成DatagramPacket 包裹
				byte[] container = new byte[1024 * 60];
				DatagramPacket packet = new DatagramPacket(container, container.length);
				// 3、阻塞式接收包裹
				server.receive(packet);
//				frame.isconnect=1;
				// 4、分析数据
				byte[] datas = packet.getData();
				String msg = new String(datas, 0, packet.getLength());
				String mes[] = msg.split("\n");
//				System.out.println(from + ":" + msg);
				System.out.println(mes[0] + "   " + mes[1] + "\n");
//				frame.messageShow.setText(from + ":" + msg);
				if (MainFrame.userlinklist.findUser(mes[0]).frame == null)
					System.out.println("is null");
				MainFrame.userlinklist.findUser(mes[0]).frame.setVisible(true);
				MainFrame.userlinklist.findUser(mes[0]).frame.messageShow.append("    " + mes[0] + ":" + mes[1] + "\n");
				System.out.println(MainFrame.userlinklist.findUser(mes[0]).getUserName());
				if (msg.equals("bye")) {
					break;
				}
			} catch (IOException e) {
				System.out.println("here");
				e.printStackTrace();
			}
		}
		// 5、释放资源
		server.close();
		System.out.println("释放：" + port + "  " + from + "\n");
	}

}